package com.monsanto.mbt;

import java.util.ArrayList;
import java.util.List;

public class WareHouse {
	private static WareHouse myObj;
	
	private static List<Widget> widgets;

	static{
        myObj = new WareHouse();
        widgets = new ArrayList();
    }
     
    private WareHouse(){
     
    }
     
    public static WareHouse getInstance(){
        return myObj;
    }
     
	public List<Widget> getWidgets() {
		return widgets;
	}

	public void setWidgets(List<Widget> widgets) {
		this.widgets = widgets;
	}
	 
}
